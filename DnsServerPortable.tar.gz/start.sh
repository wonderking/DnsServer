#!/bin/sh

dotnet DnsServerApp.dll
